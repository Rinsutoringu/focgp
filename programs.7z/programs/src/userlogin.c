#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include "../inc/define_struct.h"

// 跨平台
#include "../inc/cross_platform_dirent.h"
#ifdef _WIN32

// 打开目录
DIR *opendir(const char *name) {
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    if (!dir) {
        perror("malloc");
        return NULL;
    }

    // 构造搜索路径（加上 \* 以匹配目录下的所有文件）
    dir->path = (char *)malloc(strlen(name) + 3);
    if (!dir->path) {
        free(dir);
        perror("malloc");
        return NULL;
    }
    snprintf(dir->path, strlen(name) + 3, "%s\\*", name);

    dir->handle = FindFirstFile(dir->path, &dir->find_data);
    if (dir->handle == INVALID_HANDLE_VALUE) {
        free(dir->path);
        free(dir);
        return NULL;
    }

    dir->first_read = 1; // 标记为第一次读取
    return dir;
}

// 读取目录
struct dirent *readdir(DIR *dirp) {
    static struct dirent entry;

    if (!dirp) {
        return NULL;
    }

    // 第一次读取
    if (dirp->first_read) {
        dirp->first_read = 0;
    } else {
        // 后续读取
        if (!FindNextFile(dirp->handle, &dirp->find_data)) {
            return NULL;
        }
    }

    // 复制文件名到跨平台的 dirent 结构
    strncpy(entry.d_name, dirp->find_data.cFileName, MAX_PATH);
    return &entry;
}

// 关闭目录
int closedir(DIR *dirp) {
    if (!dirp) {
        return -1;
    }

    if (dirp->handle != INVALID_HANDLE_VALUE) {
        FindClose(dirp->handle);
    }

    free(dirp->path);
    free(dirp);
    return 0;
}

#else

// 如果是 Linux 或 macOS，直接使用系统的 <dirent.h> 提供的实现
DIR *opendir(const char *name) {
    return opendir(name);
}

struct dirent *readdir(DIR *dirp) {
    return readdir(dirp);
}

int closedir(DIR *dirp) {
    return closedir(dirp);
}

#endif
/*
##############################################
这个函数用来完成用户的登录操作
先读取配置文件中的账号密码
然后与用户输入的账号密码进行按对匹配
如果任意对匹配上后，返回0
匹配不上，返回1
##############################################
*/
int userlogin(char filename[])
{

    char* arr[10];
    int i = 0;
    char* line = NULL;
    char buffer[100] = {0};
    // 先从文件中读取全部用户名和密码
    FILE *file;
    file = fopen(filename, "r");
    if (file == NULL)
    {
        printf("file open error\n");
        return 1;
    }
    // 获取文件行数
    while (fgets(buffer, 100, file) != NULL)
    {
        i++;
    }

    // 重置文件读写指针
    fseek(file, 0, SEEK_SET);
    
    // 创建存储文件内每一行字符串的数组
    char *getline[i];



    // 获取存储文件每一行的字符串指针
    for (int n = 0; n < i; n++)
    {
        fgets(buffer, 100, file);
        buffer[strcspn(buffer, "\n")] = '\0';
        // 现在把文件的第一行读进了一个固定长度字符型数组里面
        line = (char *)malloc((strlen(buffer)+1)*sizeof(char));
        strcpy(line, buffer);
        getline[n] = line;
    }
    
    // 进行字符串切割
    // 声明两个二位数组用来存放数据
    char username[i][30];
    char password[i][30];

    for (int n = 0; n < i; n++)
    {
        char *token = strtok(getline[n], " ");
        strcpy(username[n], token);
        token = strtok(NULL, " ");
        strcpy(password[n], token);
    }
    
    char input_username[20] = {0};
    char input_password[20] = {0};




    // for (int n = 0; n < i; n++)
    // {
    //     printf("input username is [%s], username in txt is [%s]\ninput password is [%s], password in txt is [%s]\n", 
    //         input_username, username[n], input_password, password[n]);
    // }
    

    int Opportunity = 0;
    while (1)
    {
        memset(input_username, 0, sizeof(input_username));
        memset(input_password, 0, sizeof(input_password));
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        printf("please input your username\n");
        scanf("%s", input_username);
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        printf("please input your password\n");
        scanf("%s", input_password);

        for (int n = 0; n < i; n++)
        {
            if (strcmp(input_username, username[n]) == 0)
            {
                if ((strcmp(input_password, password[n]) == 0))
                {
                    return 0;
                }
            }
        }
        
        Opportunity++;
        if (Opportunity == 3)
        {
            return 1;
        }
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        printf("your password or username is wrong. But you still have %d choice.\n", 3-Opportunity);

    }
    

}