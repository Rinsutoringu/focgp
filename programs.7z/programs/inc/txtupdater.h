#pragma once

int txtupdater(int a);