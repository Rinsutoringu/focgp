#pragma once

int txtcreater(char filename[], struct destine_time *ordertime);
