#pragma once
#include"define_struct.h"
int userdestine(struct destine_time *time);