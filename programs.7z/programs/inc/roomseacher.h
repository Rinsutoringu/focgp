#pragma once

char* roomseacher(int room_number, struct destine_time *userorder, struct room_ini **savefile);