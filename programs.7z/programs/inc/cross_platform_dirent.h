#ifndef CROSS_PLATFORM_DIRENT_H
#define CROSS_PLATFORM_DIRENT_H

#ifdef _WIN32
    #include <windows.h>
    #include <tchar.h>

    typedef struct {
        HANDLE handle;               // Windows 的句柄
        WIN32_FIND_DATA find_data;   // 文件信息
        char *path;                  // 动态分配的目录路径
        int first_read;              // 标记是否是第一次读取
    } DIR;

    struct dirent {
        char d_name[MAX_PATH];       // 文件名
    };

    // 跨平台函数声明
    DIR *opendir(const char *name);
    struct dirent *readdir(DIR *dirp);
    int closedir(DIR *dirp);
#else
    #include <dirent.h>
#endif

#endif // CROSS_PLATFORM_DIRENT_H