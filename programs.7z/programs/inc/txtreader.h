#pragma once

struct room_ini ** txtreader(struct destine_time *ordertime, int room_number);